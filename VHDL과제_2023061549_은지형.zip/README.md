# VHDL과제

2023061549 은지형

VHDL_1 마지막 장(22쪽)의 1~5번 구현입니다.

## 제출 파일

- `vhdl/`: 과제 1~5 소스 5개 (5번 파일에 표시 디코더 포함)
- `logisim/P1_Logic4.circ` ~ `P5_Count13_Display.circ`: 문제별 프로젝트
- `report/VHDL과제_2023061549_은지형.pdf`: 보고서
- `tests/`: 시험 입력, VHDL 테스트벤치, 실행 로그

## 사용 및 검증

Logisim-evolution 5.0.0에서 `logisim/`의 문제별 `.circ` 파일을 엽니다.
손 모양 도구로 입력 값을 변경할 수 있습니다. 같은 이름의 터널은 전기적으로 연결되어 있습니다.
`display(7 downto 0)`는 `a b c d e f g dp` 순서이며 1일 때 점등합니다.

Logisim과 Questa에서 동일한 19,057건의 시험이 모두 통과했습니다.
1번 16건, 2번 2,048건, 3번 8건, 4번 569건, 5번 16,384건, 5번 파일에 포함된 디코더 32건입니다.
4번은 전수 검사가 아니라 경계값, 비트 위치 변경, 난수와 전이 시험입니다.

Questa Altera Starter FPGA Edition 2025.2에서 VHDL-2008 컴파일 오류/경고 0건입니다.
시뮬레이션 오류는 없으며 `+acc` 때문에 발생한 최적화 안내 경고 1건은 기능 실패와 무관합니다.
최종 결과: `tests/vhdl_status.txt`, `tests/questa_verification.log`, `tests/logisim_results.json`.

Questa 재실행은 한글이 없는 폴더에서 아래 순서로 수행합니다.

```tcl
vlib work
vmap -c
vmap work work
vcom -2008 vhdl/p1_logic4.vhd vhdl/p2_mux8_1.vhd vhdl/p3_letters.vhd vhdl/p4_vote25.vhd vhdl/p5_count13_display.vhd tests/tb_homework.vhd
vsim -c -onfinish exit -do tests/run_questa.do
```

Windows에서는 TEMP/TMP도 한글이 없는 작업용 폴더로 지정하면 Questa 실행 문제를 피할 수 있습니다.
13비트에서 1의 개수는 최대 13이므로 5번에서는 E/F가 나오지 않습니다. 5번 파일에 포함된 디코더는 0~F를 모두 구현했습니다.

## 참고 자료

- 수업 자료 `VHDL_1`, 22쪽
- 예제 코드: https://github.com/lizhuoh9/VHDL_code

예제에서 4입력 논리, 8:1 선택기, 25인 투표, 문자 및 개수 표시로 확장했습니다.
투표 출력의 누락 대입과 숫자 표시 패턴을 수정했으며 IEEE numeric_std를 사용했습니다.
