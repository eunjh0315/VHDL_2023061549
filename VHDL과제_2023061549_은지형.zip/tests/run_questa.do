transcript on
puts "HOMEWORK_SIMULATION_START"
onerror {quit -code 1 -force}
vsim -voptargs=+acc work.tb_homework
puts "HOMEWORK_DESIGN_LOADED"
puts "SIMULATION_TOPS: [find instances /*]"
run -all
quit -code 0 -force
