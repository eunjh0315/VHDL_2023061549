-- Optional VHDL-2008 testbench. Run from the repository root; see README.md.
-- Reads the same expected-value vectors that were used for Logisim verification.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_textio.all;
use std.textio.all;
use std.env.all;

entity tb_homework is end entity;
architecture test of tb_homework is
    signal a,b,c,d,o1,o2 : std_logic := '0';
    signal din : std_logic_vector(7 downto 0) := (others=>'0');
    signal sel,code : std_logic_vector(2 downto 0) := (others=>'0');
    signal muxout,en,hen,result : std_logic := '0';
    signal vt25 : std_logic_vector(24 downto 0) := (others=>'0');
    signal vt13 : std_logic_vector(12 downto 0) := (others=>'0');
    signal count25 : std_logic_vector(4 downto 0);
    signal count13,hdat : std_logic_vector(3 downto 0) := (others=>'0');
    signal letters,display,hdisplay : std_logic_vector(7 downto 0);
begin
    p1: entity work.p1_logic4 port map(a,b,c,d,o1,o2);
    p2: entity work.p2_mux8_1 port map(din,sel,muxout);
    p3: entity work.p3_letters port map(code,letters);
    p4: entity work.p4_vote25 port map(vt25,count25,result);
    p5: entity work.p5_count13_display port map(vt13,en,count13,display);
    hx: entity work.hex7seg port map(hen,hdat,hdisplay);
    process
        file f : text;
        file status_file : text open write_mode is "tests/vhdl_status.txt";
        variable status_line : line;
        variable l : line;
        variable b0,b1,b2,b3,e0,e1 : std_logic;
        variable v3 : std_logic_vector(2 downto 0);
        variable v4,expected4 : std_logic_vector(3 downto 0);
        variable expected5 : std_logic_vector(4 downto 0);
        variable v8,expected8 : std_logic_vector(7 downto 0);
        variable v13 : std_logic_vector(12 downto 0);
        variable v25 : std_logic_vector(24 downto 0);
        variable n : natural := 0;
        procedure open_vectors(file target : text; name : string) is
            variable header : line;
        begin
            file_open(target,"tests/" & name & ".txt",read_mode);
            readline(target,header); readline(target,header);
        end procedure;
    begin
        write(status_line, string'("START")); writeline(status_file,status_line);
        open_vectors(f,"P1_Logic4");
        while not endfile(f) loop
            readline(f,l); read(l,b0); read(l,b1); read(l,b2); read(l,b3); read(l,e0); read(l,e1);
            a<=b0; b<=b1; c<=b2; d<=b3; wait for 1 ns;
            assert o1=e0 and o2=e1 report "P1 mismatch" severity failure; n:=n+1;
        end loop; file_close(f);
        open_vectors(f,"P2_Mux8");
        while not endfile(f) loop
            readline(f,l); read(l,v8); read(l,v3); read(l,e0);
            din<=v8; sel<=v3; wait for 1 ns;
            assert muxout=e0 report "P2 mismatch" severity failure; n:=n+1;
        end loop; file_close(f);
        open_vectors(f,"P3_Letters");
        while not endfile(f) loop
            readline(f,l); read(l,v3); read(l,expected8); code<=v3; wait for 1 ns;
            assert letters=expected8 report "P3 mismatch" severity failure; n:=n+1;
        end loop; file_close(f);
        open_vectors(f,"P4_Vote25");
        while not endfile(f) loop
            readline(f,l); read(l,v25); read(l,expected5); read(l,e0); vt25<=v25; wait for 1 ns;
            assert count25=expected5 and result=e0 report "P4 mismatch" severity failure; n:=n+1;
        end loop; file_close(f);
        open_vectors(f,"P5_Count13_Display");
        while not endfile(f) loop
            readline(f,l); read(l,v13); read(l,b0); read(l,expected4); read(l,expected8);
            vt13<=v13; en<=b0; wait for 1 ns;
            assert count13=expected4 and display=expected8 report "P5 mismatch" severity failure; n:=n+1;
        end loop; file_close(f);
        open_vectors(f,"Hex_Decoder_Test");
        while not endfile(f) loop
            readline(f,l); read(l,v4); read(l,b0); read(l,expected8);
            hdat<=v4; hen<=b0; wait for 1 ns;
            assert hdisplay=expected8 report "Hex decoder mismatch" severity failure; n:=n+1;
        end loop; file_close(f);
        report "PASS: " & integer'image(n) & " VHDL vectors" severity note;
        write(status_line, string'("PASS: ")); write(status_line,n);
        write(status_line, string'(" VHDL vectors")); writeline(status_file,status_line);
        file_close(status_file);
        finish;
    end process;
end architecture;
